#include <stdio.h>
#include <stdlib.h>

struct nodeFB
{

         int id;

         int age;

         struct nodeFB *next;

};

struct nodeGS
{

         int id;

         struct nodeGS *next;

};


void printFB(struct nodeFB *fb) {
	while(fb) {
		if(fb->age>0)
		printf("Id:%d\tAge:%d\n",fb->id,fb->age);
		else
		break;
		fb=fb->next;
	}
}
void printGS(struct nodeGS *gs) {
	struct nodeGS *temp;
	temp=gs;
	while(temp) {
		if(temp->id<999999 && temp->id!=0)
		printf("Id:%d\n",temp->id);
		else
		break;
		temp=temp->next;
	}
} 
void printAll(struct nodeFB *all) {
	struct nodeFB *temp;
	temp=all;
	while(temp) {
			if(temp->id!=0)
			printf("Id:%d",temp->id);
			if(temp->age>0)
				printf("\tAge:%d",temp->age);
			printf("\n");
	
		temp=temp->next;
	}
}

int main()
{
	struct nodeFB *fb=malloc(sizeof(struct nodeFB));
	struct nodeGS *gs=malloc(sizeof(struct nodeGS));	
	struct nodeFB *tempfb,*tempall;
	struct nodeFB *all=malloc(sizeof(struct nodeFB));
	struct nodeGS *tempgs;
	int *ids=(int*)malloc(50*sizeof(int));
	int *idg=(int*)malloc(50*sizeof(int));
	int *ages=(int*)malloc(50*sizeof(int));
	int limitf=0,limitg=0,i=0,j=0,k=0,arac;
	
	while(1) {
		scanf("%d",&ids[limitf]);
		scanf("%d",&ages[limitf]);
		if(ids[limitf]==-1)
			break;
		limitf++;
	}
	for(i=0;i<limitf;i++) {
		for(j=0;j<limitf;j++) {
			if(ids[i]<ids[j]) {
				arac=ids[i];
				ids[i]=ids[j];
				ids[j]=arac;
				arac=ages[i];
				ages[i]=ages[j];
				ages[j]=arac;
			}
		}
	}

	i=0;
	tempfb=fb;
	while(i<limitf) {
		tempfb->id=ids[i];
		tempfb->age=ages[i];
		tempfb->next=0;
		tempfb->next=malloc(sizeof(struct nodeFB));;
		tempfb=tempfb->next;
		i++;
	}i=0;
	
	while(1) {
		scanf("%d",&idg[limitg]);
		if(idg[limitg]==-1)
			break;
		limitg++;
	}
	for(i=0;i<limitg;i++) {
		for(j=0;j<limitg;j++) {
			if(idg[i]>idg[j]) {
				arac=idg[i];
				idg[i]=idg[j];
				idg[j]=arac;
			}
		}
	}i=0;
	tempgs=gs;
	while(i<limitg) {
		tempgs->id=idg[i];
		tempgs->next=0;
		tempgs->next=malloc(sizeof(struct nodeGS));
		tempgs=tempgs->next;
		i++;
	}i=0;
	j=0;
	k=0;

	
	printFB(fb);
	printf("\n");
	printGS(gs);
	printf("\n");
	tempall=all;
	while(i<limitf+limitg) {
		if(i%2==0) {
			tempall->id=ids[j];
			tempall->age=ages[j];
			tempall->next=0;
			j++;
		}
		else if(i%2==1) {
			tempall->id=idg[k];
			tempall->age=0;
			tempall->next=0;
			k++;
		}
		tempall->next=malloc(sizeof(struct nodeFB));
		tempall=tempall->next;
		i++;
	}
	printAll(all);

	return 0;
}

