#include <stdio.h>
#include <stdlib.h>
#define MAX 5
int top;
struct stack {
	int employees[6];
	int empwork[6];
};
struct queue {
	int customers;
	struct queue *next;
	int time;
};

int main()
{
	struct stack *emp=malloc(sizeof(struct stack));
	struct queue *cus=malloc(sizeof(struct queue));
	struct queue *temp;
	int *transaction=malloc(50*sizeof(int));
	int *worktime=malloc(50*sizeof(int));
	int i=0,counter=0,k,wait=0,control,arac;
	int arr[50][5];
	//stack of employees
	while(i<6) {
	emp->employees[i]=i+1;
	emp->empwork[i]=0;
	top=i;
		i++;
	}
	for(i=0;i<50;i++) {
		for(k=0;k<5;k++)
			arr[i][k]=0;
	}
	
	//taking inputs customers,time & worktime
	temp=cus;
	while(temp->customers!=-1) {
		scanf("%d",&temp->customers);
		if(temp->customers==-1)
			break;
		scanf("%d",&temp->time);
		scanf("%d",&transaction[counter++]);
		temp->next=malloc(sizeof(struct queue));
		temp=temp->next;
		
	}
	
	i=0;
	while(cus) {
		
		control=0;
		if(top<0) {
			wait++;
			worktime[i]++;
			cus->time++;
			top=MAX;
		}
		worktime[i]=transaction[i]+cus->time;
		
		
			arr[i][0]=cus->customers;
			arr[i][1]=emp->employees[top];
			arr[i][2]=cus->time;
			arr[i][3]=worktime[i];
			arr[i][4]=wait;
		
		for(k=0;k<=i;k++) {
			if(worktime[k]==cus->time && arr[k][3]==cus->time) {
			arac=top;
			top=arr[k][1]-1;
			printf("%d\t%d\t%d\t%d\t%d\n",cus->customers,emp->employees[top],cus->time,worktime[i],wait);
			arr[i][1]=emp->employees[top];
			emp->empwork[top]+=transaction[i];
			top=arac;
			arr[k][3]=0;
			control=1;	
			break;
			}
		}
			if(control==0) {
			printf("%d\t%d\t%d\t%d\t%d\n",cus->customers,emp->employees[top],cus->time,worktime[i],wait);
			emp->empwork[top]+=transaction[i];
			top--; }
		cus=cus->next;
		i++;
		if(cus->customers==-1)
			break;
	}
	printf("\n");
	for(i=5;i>=0;i--) 
		printf("%d\t%d\n",emp->employees[i],emp->empwork[i]);
	
	
	
	return 0;
}






