#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <stdio.h>

int main() {

pid_t pid;	
int sumfn=0,fn;
int user_input;
int fd[2];
int value1=0, value2=1;
int counter;
int referance, referance2;

pipe(fd);

pid = fork();

if(pid<0) {
	perror("exit");
	exit(1);
}

if(pid==0)  {  //child process
	
	referance = read(fd[0], &user_input, sizeof(user_input));
	
	printf("I am child: I took the input\n");	
	if(user_input==0) {
		sumfn=0;
		fn=0;
	}
	
	else if(user_input==1) {
		sumfn=1;
		fn=1;
	}
	
	else {		
		sumfn=1;	
		for(counter=0;counter<user_input-1;counter++) {
			fn = value1 + value2;
			sumfn += fn;
			value1 = value2;	
			value2 = fn;						
		}	

	}
		
	printf("I am child: Sending the sum of fibonacci serie\n");	
	
	write(fd[1], &fn, sizeof(fn));
	
	wait(NULL);	
	write(fd[1], &sumfn, sizeof(sumfn));
	
	close(fd[0]);
	close(fd[1]);
	return EXIT_SUCCESS;
	
}

if(pid>0) {  //parent process
	
	printf("I am parent: Please enter the input : ");
	scanf("%d",&user_input);
	write(fd[1], &user_input, sizeof(user_input));
	
	wait(NULL);
	if(user_input<0) {
		printf("Input cannot be negative integer!\n");
		exit(0);
	}

	referance2 = read(fd[0], &fn, sizeof(fn));
	printf("I am parent: Value of fibonacci serie (fn) : %d\n",fn);
	
	wait(NULL);
	referance2 = read(fd[0], &sumfn, sizeof(sumfn));
	printf("I am parent: Sum of fibonacci serie's number (sumfn) : %d\n",sumfn);
	close(fd[0]);
	close(fd[1]);
	
	return EXIT_SUCCESS;
	
}

return 0;

}
