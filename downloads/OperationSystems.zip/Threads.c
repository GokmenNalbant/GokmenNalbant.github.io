#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#define FILENAME "input.txt"

int read_lines;
int read_sentences;
FILE *fp;
int line_to_read;

 void *thread_runner(void *t) {
    read_sentences = 0;
    read_lines = 0;
    int i=0;
    long tid;
    tid = (long)t;
    printf("Thread %ld starting...\n",tid+1);
    char *line_buf = NULL;
    size_t line_buf_size = 0;
    int number_of_lines = 0;
    ssize_t line_size;
    while (i<line_to_read) {
        line_size = getline(&line_buf, &line_buf_size, fp);
        
        if(line_size <= 0)
            break;
        i++;
        read_lines++;
        int j;
        for(j=0;line_buf[j]!='\0';j++) {
            if(line_buf[j] == '.' || line_buf[j] == '!' || line_buf[j] == '?')
                read_sentences++;
           
        }
    }
    
    
    pthread_exit((void*) t);
 }

 int main (int argc, char *argv[])
 {
    int x;
    scanf("%d",&x);
    pthread_t thread[x];
    pthread_attr_t attr;
    int rc;
    long t;
    void *status;
    
    char *line_buf = NULL;
    size_t line_buf_size = 0;
    int number_of_lines = 0;
    ssize_t line_size;
    FILE *filep;
    filep = fopen(FILENAME,"r");
    if(filep == NULL) {
      perror("Error opening file");
      return(-1);
   }
    // find number of lines
    line_size = getline(&line_buf, &line_buf_size, filep);
    while (line_size >= 0) {
    number_of_lines++;
    line_size = getline(&line_buf, &line_buf_size, filep);
    }
    fclose(filep);
    free(line_buf);
     // find how many lines threads read
    if(number_of_lines % x == 0)
        line_to_read = number_of_lines/x;
    else
        line_to_read = (number_of_lines/x)+1;
    
    /* Initialize and set thread */
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
	
	fp = fopen(FILENAME,"r");
    for(t=0; t<x; t++) {
       printf("Main: creating thread %ld\n", t+1);
       rc = pthread_create(&thread[t], &attr, thread_runner, (void *)t);  
       rc = pthread_join(thread[t], &status);
       if (rc) {
          printf("ERROR; return code from pthread_create() is %d\n", rc);
          exit(-1);
          }
        printf("Number of Lines : %d\t Number Of Sentences : %d\n",read_lines,read_sentences);
       }

 
 printf("Main: program completed. Exiting.\n");
 pthread_exit(NULL);
 }
