import java.net.*;
import java.io.*;
import java.util.Scanner;


public class Client {
    public static void main(String[] args) throws IOException {
        Socket s= new Socket("localhost",9999);
		Scanner secim = new Scanner(System.in);
		
		System.out.println("CLIENT:: STONE or PAPER or SCISSORS?");
		
		PrintWriter user_input = new PrintWriter(s.getOutputStream());
		user_input.println(secim.next());
		user_input.flush();
		
		InputStreamReader in = new InputStreamReader(s.getInputStream());
		BufferedReader bf = new BufferedReader(in);
		
		String result = bf.readLine();
		System.out.println("CLIENT:: Result : " + result);
		
    }
}