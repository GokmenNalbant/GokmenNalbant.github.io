import java.net.*;
import java.io.*;
import java.util.Random;


public class Server {
    public static void main(String args[]) throws IOException {
        ServerSocket ss = new ServerSocket(9999);
        Socket s = ss.accept();
        String Computer_Selection = "";
        int numberForPc;
		String result = "";
		String makas = "scissors";
		makas = makas.toUpperCase();
		InputStreamReader in = new InputStreamReader(s.getInputStream());
		BufferedReader bf = new BufferedReader(in);
		
		String User_Selection = bf.readLine();
		User_Selection = User_Selection.toUpperCase();
		System.out.println("SERVER:: User select : "+User_Selection);
		
		Random generate = new Random(); 
        numberForPc = generate.nextInt(3)+1; 
       
		if (numberForPc == 1) 
           Computer_Selection = "Stone";
       else if (numberForPc == 2)
		   Computer_Selection = "Paper"; 
       else if (numberForPc == 3) 
           Computer_Selection= "Scissors"; 
		
		Computer_Selection = Computer_Selection.toUpperCase();
		System.out.println("SERVER:: Computer select : "+Computer_Selection);
	
		if(User_Selection.equals(Computer_Selection)) {
			result = "DRAW!";
		}
		else if(User_Selection.equals("PAPER")) {
			if(Computer_Selection.equals("STONE")) {
				result = "YOU WIN!";
			}
			else if(Computer_Selection.equals("SCISSORS") || Computer_Selection.equals(makas)) {
				result = "YOU LOST!";
			}
		}
		else if(User_Selection.equals("STONE")) {
			if(Computer_Selection.equals("SCISSORS") || Computer_Selection.equals(makas)) {
				result = "YOU WIN!";
			}
			else if(Computer_Selection.equals("PAPER")) {
				result = "YOU LOST!";
			}
		}	
		else if(User_Selection.equals("SCISSORS") || User_Selection.equals(makas)) {
			if(Computer_Selection.equals("PAPER")) {
				result = "YOU WIN!";
			}
			else if(Computer_Selection.equals("STONE")) {
				result = "YOU LOST!";
			}
		}
		
		System.out.println("SERVER:: Result : " + result);
		
		PrintWriter Sending_Result = new PrintWriter(s.getOutputStream());
		Sending_Result.println(result);
		Sending_Result.flush();
		
		
	}
}