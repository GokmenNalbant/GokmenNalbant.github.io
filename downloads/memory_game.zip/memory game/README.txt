=>Oyun memory_game.py dosyası ile çalışır.

=>"Memory Game" klasörünü masaüstüne çıkarın. Klasörün içindeki "numberss.py" dosyasının   içerisinde bulunan rakamların fotoğraflarının dosya adreslerini bilgisayarınıdaki dosya   adresleriyle değiştirmeniz gerekebilir. Değiştirdikten sonra oyun sorun çıkarmayacaktır.
("C:\Users\User\Desktop\memory game\image.bmp" şeklinde olan dosya adresini numberss.py dosyasının içerisine yazarken ters slashları '\', normal slash '/' yapmayı unutmayın.)

!!! İYİ OYUNLAR !!!