class Settings():
    
    def __init__(self):
        self.screen_width = 1200
        self.screen_height = 790
        self.back_ground_color = (80,20,20)

        self.back_ground_color2 = (0,255,20)